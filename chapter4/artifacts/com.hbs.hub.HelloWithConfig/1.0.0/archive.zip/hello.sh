#!/bin/bash

echo "Hello from `cat config.txt`!"
